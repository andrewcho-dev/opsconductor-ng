def test_step(message: str) -> dict:
    """Simple test step"""
    return {"result": f"Test message: {message}"}